import datetime
import random
import boto3
import json
# Create an S3 client
s3 = boto3.client('s3')

#s3 = boto3.resource('s3')
from boto3.dynamodb.conditions import Key, Attr

# if wanted to use another table, use substitute for table
TABLE_NAME = "Stocks"

# Creating the DynamoDB Client
dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")

# Creating the DynamoDB Table Resource
dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
table = dynamodb.Table(TABLE_NAME)

# Creating the DynamoDB Table Resource if including second table
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Stocks')

# defining objects and bucket to upload
def put_object(dest_bucket_name, dest_object_name, src_data):
    """Add an object to an Amazon S3 bucket

    The src_data argument must be of type bytes or a string that references
    a file specification.

    :param dest_bucket_name: string
    :param dest_object_name: string
    :param src_data: bytes of data or string reference to file spec
    :return: True if src_data was added to dest_bucket/dest_object, otherwise
    False
    """
# defining object and bucket source to delete object
def delete_object(bucket_name, object_name):
    """Delete an object from an S3 bucket

    :param bucket_name: string
    :param object_name: string
    :return: True if the referenced object was deleted, otherwise False
    """
# creating menu selection
print("Select operation.")
print("1.How to use this application")
print("2.Create a text file")
print("3.Upload text file to S3 bucket")
print("4.Delete file from S3 bucket")
print("5.Download Object")
print("6.Edit Text file")
print("7.Create DynamoDB Table")
print("8.Load DynamoDB Table")
print("9.Search by stock symbol")
print("10.Search by stock name")

# using loop and if-else statements for switch 
while True:
    # Take input from the user
    choice = input("Enter choice(1/2/3/4/5/6/7/8/9/10): ")

    # Check if choice is one of the options
    if choice in ('1', '2', '3', '4', '5', '6', '7', '8', '9','10'):
        
        if choice == '1':
            print(" ")
            print("This simple application is for users to save stocks in DynamoDB and store files/notes in S3.")
            print("However, users may use this for organizing almost anything.")
            print("Users may share files when files are added to public folders in S3 (ex. sdev400.image folder)")
            print("Enter number selection and follow the prompt.")
        
        # Creates a file, returns an error if the file exist
        elif choice == '2':
            userTxt = (input("Enter Text here (sampleFile): "))
            f = open((userTxt  + ".txt") , "x")
            f.close()
            print("Your file was created.")
            
        # Uploads object to S3 bucket
        elif choice == '3':  
            userTxt = (input("Enter Text here (sampleFile): "))
            fileName = (userTxt + ".txt")
            s3.put_object(Bucket='sdev400.image', Key=fileName, Body="/home/ec2-user/environment/'fileName'")
        
        # Deletes file in S3 bucket
        elif choice == '4':
                try:
                    userTxt = (input("Enter filename (samplefile): "))
                    fileName = (userTxt + ".txt")
                except ValueError:
                    print("Sorry, Please try again.")
                else:    
                    s3.delete_object(Bucket='sdev400.image', Key=fileName)
        
        # Dpwnloads file from S3 to Cloud9           
        elif choice == '5':
            s3 = boto3.resource('s3')
            userTxt = (input("Enter filename to download (samplefile): "))
            userTxt2 = (input("Enter New file name to save(samplefile2): "))
            fileName = (userTxt + ".txt")
            fileName2 = (userTxt2 + ".txt")
            bucket = s3.Bucket('sdev400.image')
            key = fileName
            # checks if it exists or not first
            objs = list(bucket.objects.filter(Prefix=key))
            if len(objs) > 0 and objs[0].key == key:
                print("Exists!")
                # Once determines object exist then will download object
                bucket = 'sdev400.image' 
                KEY = fileName 
                s3 = boto3.resource('s3')
                s3.Bucket(bucket).download_file(KEY, fileName2)
            else:
                print("Doesn't exist")
        
        # Edits text file by adding new text
        elif choice == '6':
            userTxt = (input("Enter filename (samplefile): "))
            fileName = (userTxt + ".txt")
            bodyTxt = (input("Enter comments: "))
            f = open(fileName, "a")
            f.write("\n" + bodyTxt)
            f.close()
            print("Your comment was added.")
        
        # Creates Table in DynamoDB 
        elif choice == '7':
            usertxt = (input("Enter table name: "))
            usertxt1 = (input("Enter Partition key: "))
            usertxt2 = (input("Enter Sort key: "))
            usertxt3 = (input("Enter datatype for Partition key: "))
            usertxt4 = (input("Enter datatype for Sort key: "))
            table = dynamodb.create_table(
                TableName=usertxt,
                KeySchema=[
                    {
                        'AttributeName': usertxt1,
                        'KeyType': 'HASH'  #Partition key
                    },
                    {
                        'AttributeName': usertxt2,
                        'KeyType': 'RANGE'  #Sort key
                    }
                ],
                AttributeDefinitions=[
                    {
                        'AttributeName': usertxt1,
                        'AttributeType': usertxt3
                    },
                    {
                        'AttributeName': usertxt2,
                        'AttributeType': usertxt4
                    },

                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 20,
                    'WriteCapacityUnits': 20
                }
            )
            # If something goes wrong this will prints out status/errors
            print("Table status:", table.table_status)
        
        # Loads json file to add data to DynamoDB Table
        elif choice == '8':
            usertxt = (input("Enter json filename (MyStocks.json): "))
            f = open(usertxt)
            request_items = json.loads(f.read())
            client = boto3.client('dynamodb')
            response = client.batch_write_item(RequestItems=request_items)
            # This will prints out the response, if errors then will show
            print(response)
        
        # Search by stock symbol of Table Stocks as example   
        elif choice == '9':
            try:
                a = (input("Enter the stock symbol (CVS): "))
                response = table.query(
                    KeyConditionExpression=Key('stockSymbol').eq(a)
                )
                print(response['Items'])
            except:
                # If something is wrong will print this statement. 
                print('Please try again')
        # Search by stock name on DynamoDB Table        
        elif choice == '10':
                    try:
                        a = (input("Enter the stock Name (CVS Health Corp): "))
                        response = table.scan(
                            FilterExpression=Key('stockName').eq(a)
                        )
                        # Prints a listing of the attributes in table
                        for i in response['Items']:
                            stName = (i['stockName'])
                            stSym = (i['stockSymbol'])
                            stMarket = (i['market'])
                            stPrice = (i['price'])
                            stmktCap = (i['mktCap'])
                            stPERatio = (i['P/E Ratio'])
                            stDivYield = (i['Div yield'])
                            stSharesOwn = (i['SharesOwn'])
                        print("\n" + stName +", symbol is " + stSym + " " + "at " + "$" + stPrice + " " + "per share")
                        print("Market: " + stMarket + ", MarketCap: " + stmktCap + ", P/E ratio: " + stPERatio +", Dividend Yield %: " + stDivYield +", Number of Shares Own: "+ stSharesOwn)
                    except:
                        # If something goes wrong will show this statement
                        print("Please try again")
                        
        break
print("Exiting program.")
z = datetime.datetime.now()
print(z)
